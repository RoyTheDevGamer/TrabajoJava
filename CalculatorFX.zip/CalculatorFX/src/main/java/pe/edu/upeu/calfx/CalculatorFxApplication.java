package pe.edu.upeu.calfx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculatorFxApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculatorFxApplication.class, args);
	}

}
