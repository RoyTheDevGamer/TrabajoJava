package pe.edu.upeu.calfx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorFxApplicationTests {

	@Test
	void contextLoads() {
	}

}
