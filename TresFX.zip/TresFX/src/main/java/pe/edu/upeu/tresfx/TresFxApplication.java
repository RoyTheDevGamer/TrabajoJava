package pe.edu.upeu.tresfx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TresFxApplication {

	public static void main(String[] args) {
		SpringApplication.run(TresFxApplication.class, args);
	}

}
