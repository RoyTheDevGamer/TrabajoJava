package pe.edu.upeu.tresfx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TresFxApplicationTests {

	@Test
	void contextLoads() {
	}

}
