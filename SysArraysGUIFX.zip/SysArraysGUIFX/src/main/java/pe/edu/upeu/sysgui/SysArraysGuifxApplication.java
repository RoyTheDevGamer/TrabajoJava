package pe.edu.upeu.sysgui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysArraysGuifxApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysArraysGuifxApplication.class, args);
	}

}
