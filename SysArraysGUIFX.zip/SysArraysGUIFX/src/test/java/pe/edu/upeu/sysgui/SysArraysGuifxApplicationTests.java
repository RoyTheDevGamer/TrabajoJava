package pe.edu.upeu.sysgui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysArraysGuifxApplicationTests {

	@Test
	void contextLoads() {
	}

}
